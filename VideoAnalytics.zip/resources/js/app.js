require('./bootstrap');
<<<<<<< HEAD

require('alpinejs');
=======
>>>>>>>  Initial commit
