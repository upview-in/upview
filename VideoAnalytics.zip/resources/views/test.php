<?php
header("Refresh:1");
echo date('H:i:s Y-m-d');
?>