@section('path-navigation')
<a class="breadcrumb-item" href="#">Analayze</a>
<a class="breadcrumb-item" href="#">Youtube</a>
<span class="breadcrumb-item active">Audience</span>
@endsection

<x-app-layout title="Audience">
    <div class="container-fluid">
    </div>
</x-app-layout>