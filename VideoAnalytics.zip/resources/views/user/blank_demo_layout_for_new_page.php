
<x-app-layout title="Instagram Analysis">
    <div class="container-fluid">
        <div class="card">
            <div class="row">
                <div class="col-md-6 col-sm-9 col-12">
                    <div class="input-affix m-b-10">
                        <div class="container-fluid">
                            <div class="card shadow" id="ChannelMainDiv">

                            </div>
                        </div>   
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>

