<?php

return [

    'Old Password' => 'જુનો પાસવર્ડ',

];
